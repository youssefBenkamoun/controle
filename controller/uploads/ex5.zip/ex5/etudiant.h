#ifndef ETUDIANT_H
#define ETUDIANT_H
#include<iostream>
#include<string>
using namespace std;

class Etudiant{
    protected:
    string nom;
    string prenom;
    unsigned int CNE;

    public:
    Etudiant(string nom,string prenom,int cne);
    Etudiant();
    string getNom();
    string getPrenom();
    int getCne();
    void setNom(string nom);
    void setPrenom(string prenom);
    void setCne(int cne);
    virtual void afficher();

};
#endif