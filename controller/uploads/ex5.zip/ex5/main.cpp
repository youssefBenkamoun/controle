#include<iostream>
#include <cstdlib>
#include "etudiant.h"
#include "employee.h"
#include "etudiantemployee.h"
using namespace std;

int main(){
    Etudiant e1;
    e1.setCne(1);
    e1.setNom("winner");
    e1.setPrenom("ilias");
    e1.afficher();
    e1.getNom();
    Employe e2(22,"admin",22000);
    e2.getPosteOccupe();
    e2.setNumEmploye(10);
    e2.getNumEmploye();

    EtudiantEmploye e4("benkamoun","youssef",1,22,"admin",15000);
    e4.afficher();
} 
