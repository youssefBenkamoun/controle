#include "etudiant.h"
using namespace std;

Etudiant::Etudiant(){
    this->nom = "";
    this->prenom = "";
    this->CNE = 0;
}
Etudiant::Etudiant(string nom,string prenom,int cne){
    this->nom = nom;
    this->prenom = prenom;
    this->CNE = cne;
}
int Etudiant::getCne(){
    return this->CNE;
}
string Etudiant::getNom(){
    return this->nom;
}
string Etudiant::getPrenom(){
    return this->prenom;
}
void Etudiant::setCne(int cne){
    this->CNE = cne;
}
void Etudiant::setNom(string nom){
    this->nom = nom;
}
void Etudiant::setPrenom(string prenom){
    this->prenom = prenom;
}
void Etudiant::afficher(){
    cout<<"je suis "<<this->nom<<" "<<this->prenom<<" mon numero est "<<this->CNE<<endl;
}
