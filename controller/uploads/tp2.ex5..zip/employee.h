#ifndef EMPLOYE_H
#define EMPLOYE_H
#include<iostream>
#include<string>
using namespace std;

class Employe{
    protected:
    string posteOccupe;
    unsigned int salaire,numEmploye;

    public:
    Employe(int numEmploye,string posteOccupe,int salaire);
    Employe();
    int getNumEmploye();
    int getSalaire();
    string getPosteOccupe();
    void setNumEmploye(int numEmploye);
    void setPosteOccupe(string posteOccupe);
    void setSalaire(int salaire);
    virtual void afficher();

};
#endif