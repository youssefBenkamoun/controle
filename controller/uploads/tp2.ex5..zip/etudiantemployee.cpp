#include "etudiantemployee.h"
#include "etudiant.h"
#include "employee.h"
#include<iostream>
#include<string>
using namespace std;

EtudiantEmploye::EtudiantEmploye(string nom,string prenom,int cne,int numEmploye,string posteOccupe,int salaire):Etudiant(nom,prenom,cne),Employe(numEmploye,posteOccupe,salaire){}
void EtudiantEmploye::afficher(){
    Etudiant::afficher();
    Employe::afficher();
}
