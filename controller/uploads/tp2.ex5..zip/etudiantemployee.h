#ifndef ETDEMP_H
#define ETDEMP_H
#include "etudiant.h"
#include "employee.h"
class EtudiantEmploye:public Etudiant,public Employe{
    public:
    EtudiantEmploye(string nom,string prenom,int cne,int numEmploye,string posteOccupe,int salaire);
    virtual void afficher();
};
#endif