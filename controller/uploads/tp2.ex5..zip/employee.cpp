#include "employee.h"
using namespace std;

Employe::Employe(){
    this->posteOccupe = "";
    this->numEmploye = 0;
    this->salaire = 0;
}
Employe::Employe(int numEmploye,string posteOccupe,int salaire){
    this->numEmploye = numEmploye;
    this->posteOccupe = posteOccupe;
    this->salaire = salaire;
}
int Employe::getNumEmploye(){
    return this->numEmploye;
}
string Employe::getPosteOccupe(){
    return this->posteOccupe;
}
int Employe::getSalaire(){
    return this->salaire;
}
void Employe::setNumEmploye(int numEmploye){
    this->numEmploye = numEmploye;
}
void Employe::setPosteOccupe(string posteOccupe){
    this->posteOccupe = posteOccupe;
}
void Employe::setSalaire(int salaire){
    this->salaire = salaire;
}
void Employe::afficher(){
    cout<<"mon nombreEmploye est "<<this->numEmploye<<" mon poste est "<<this->posteOccupe<<" mon salaire est "<<this->salaire<<endl;
}