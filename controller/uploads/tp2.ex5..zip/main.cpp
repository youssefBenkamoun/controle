#include<iostream>
#include <cstdlib>
#include "etudiant.h"
#include "employee.h"
#include "etudiantemployee.h"
using namespace std;

int main(){
    Etudiant e1;
    e1.setCne(1);
    e1.setNom("winner");
    e1.setPrenom("ilias");
    e1.afficher();
    cout<<e1.getNom()<<endl;
    Employe e2(22,"admin",22000);
    cout<<e2.getPosteOccupe()<<endl;
    e2.setNumEmploye(10);
    cout<<e2.getNumEmploye()<<endl;

    EtudiantEmploye e4("benkamoun","youssef",1,22,"admin",15000);
    e4.afficher();
} 
